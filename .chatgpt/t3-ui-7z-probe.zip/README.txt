7z extraction probe
